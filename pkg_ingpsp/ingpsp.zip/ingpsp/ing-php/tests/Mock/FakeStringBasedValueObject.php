<?php

namespace GingerPayments\Payment\Tests\Mock;

use GingerPayments\Payment\Common\StringBasedValueObject;

final class FakeStringBasedValueObject
{
    use StringBasedValueObject;
}
